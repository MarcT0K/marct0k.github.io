# Multilingual spam dataset

This dataset was built by Raj Nath Patel (https://www.kaggle.com/rajnathpatel).

This dataset is mainly used to test the zero-shot transfer for text classification using pretrained language models. The original text was in English and Machine Translated to Hindi, German and French. 

The original English dataset was created by Tiago Almeida and Jos Hidalgo. It is available here: https://archive.ics.uci.edu/dataset/228/sms+spam+collection

